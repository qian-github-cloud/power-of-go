



func test() {
	fmt.Println("hello world")
}