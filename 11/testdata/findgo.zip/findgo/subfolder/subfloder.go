

func sub() {
	fmt.Println("sub")
}